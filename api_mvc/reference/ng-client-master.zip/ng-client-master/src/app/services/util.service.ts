import { Injectable }       from '@angular/core';


@Injectable()
export class UtilService {
  env:any;

  constructor() {
    // this.env = this.envService;
    // let initParams: InitParams = {
    //   appId: this.env.facebook_app_id,
    //   xfbml: true,
    //   version: 'v2.8'
    // };
    // this.fb.init(initParams);
  }

}
