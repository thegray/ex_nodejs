export interface User {
  email?:string,
  phone?:string,
  newPassword?:string,
  first?:string,
  last?:string,
  auth?:boolean,
  token?:string,
}
