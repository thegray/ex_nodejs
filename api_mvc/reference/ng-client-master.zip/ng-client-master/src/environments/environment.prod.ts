export const environment = {
  production: true,
  apiUrl:'http://127.0.0.1:8080',
  facebook_app_id:'1234567890',

  app_name:'Website ProdName',
  url:'http://localhost:1515',
};
